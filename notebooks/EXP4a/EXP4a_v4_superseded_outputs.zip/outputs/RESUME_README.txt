Re-Degradation Reveals Resolution: outputs zip

To continue or finish the run in a new Kaggle session: upload this zip as a Kaggle dataset, attach it to the notebook (Add Input), and run all cells. The notebook finds the zip (or its extracted folder) under /kaggle/input, reuses every completed unit and only computes what is missing.
Snapshot: final package of this session | session elapsed 0.45 h | 2026-10-14T18:34:30
