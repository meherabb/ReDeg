"""Re-Degradation Reveals Resolution: figure renderers (CVPR 2027 camera-ready geometry).
Each renderer takes only a JSON data dict (see logs/<stem>_data.json) and returns a matplotlib Figure."""
import json, logging, os
import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Patch
from matplotlib.lines import Line2D
from matplotlib.colors import LogNorm, TwoSlopeNorm
from matplotlib.ticker import MaxNLocator, LogLocator, NullFormatter, FixedLocator, FuncFormatter
try:
    from IPython.display import display
except ImportError:
    def display(obj):
        print(obj)
logging.getLogger("matplotlib.font_manager").setLevel(logging.ERROR)

CVPR_TEXT_W, CVPR_COL_W = 6.875, 3.25
mpl.rcParams.update({
    "font.family": "serif",
    "font.serif": ["Times New Roman", "Times", "Nimbus Roman", "Liberation Serif", "STIXGeneral", "DejaVu Serif"],
    "mathtext.fontset": "stix",
    "font.size": 8, "axes.labelsize": 8, "axes.titlesize": 8,
    "xtick.labelsize": 7, "ytick.labelsize": 7, "legend.fontsize": 7, "legend.title_fontsize": 7,
    "axes.linewidth": 0.6, "lines.linewidth": 1.1, "lines.markersize": 3.5,
    "xtick.major.width": 0.6, "ytick.major.width": 0.6, "xtick.major.size": 2.5, "ytick.major.size": 2.5,
    "errorbar.capsize": 1.5, "axes.spines.top": False, "axes.spines.right": False, "axes.grid": False,
    "legend.frameon": False, "figure.dpi": 150, "figure.constrained_layout.use": True,
    "savefig.dpi": 600, "savefig.bbox": "tight", "savefig.pad_inches": 0.02,
    "pdf.fonttype": 42, "ps.fonttype": 42, "image.interpolation": "none",
})

OURS_COLOR = "#D55E00"
METHOD_STYLE = {
    "ATC_s":       dict(label="ATC@$\\hat{s}$ (ours)", color=OURS_COLOR, marker="o", lw=1.6),
    "AC":          dict(label="AC", color="#BBBBBB", marker="v", lw=1.0),
    "DoC":         dict(label="DoC", color="#7F7F7F", marker="^", lw=1.0),
    "ATC":         dict(label="ATC", color="#0072B2", marker="s", lw=1.0),
    "ATC_NE":      dict(label="ATC-NE", color="#56B4E9", marker="D", lw=1.0),
    "SAC_ATC":     dict(label="SAC-ATC", color="#E69F00", marker="P", lw=1.0),
    "AE":          dict(label="AutoEval", color="#009E73", marker="X", lw=1.0),
    "AE_LS":       dict(label="AutoEval-LS", color="#7CCBA2", marker="x", lw=1.0),
    "AE_FD":       dict(label="AutoEval-FD", color="#1E6B52", marker="+", lw=1.0),
    "NucNorm":     dict(label="NucNorm", color="#CC79A7", marker="h", lw=1.0),
    "COT":         dict(label="COT", color="#332288", marker="*", lw=1.0),
    "COTT":        dict(label="COTT", color="#8E7CC3", marker="p", lw=1.0),
    "PT":          dict(label="PT", color="#8C3800", marker="<", lw=1.0),
    "PT_anchor":   dict(label="PT-anchor", color="#A84400", marker=">", lw=1.0),
    "DoC_m":       dict(label="DoC@$\\hat{s}$", color="#C25000", marker="d", lw=1.0),
    "ATC_NE_m":    dict(label="ATC-NE@$\\hat{s}$", color="#E07B39", marker="H", lw=1.0),
    "AE_LS_s":     dict(label="AE-LS+$\\hat{s}$", color="#EC9A66", marker="8", lw=1.0),
    "ATC_m2":      dict(label="ATC@$\\hat{s}$ 2-stage", color="#F0B48C", marker="1", lw=1.0),
    "ATC_m_v11":   dict(label="ATC@$\\hat{s}$ v1.1", color="#F6C6AC", marker="2", lw=1.0),
    "ATC_m_noGOF": dict(label="ATC@$\\hat{s}$ no GOF", color="#B04A1A", marker="3", lw=1.0),
    "oracle_ATC":  dict(label="oracle ATC", color="#000000", marker="_", lw=1.0, ls="--"),
    "oracle_PT":   dict(label="oracle PT", color="#000000", marker="|", lw=1.0, ls="--"),
}
FAMILY_STYLE = {
    "ssl_blur": dict(label="SSL invariance + blur aug.", color="#CC79A7"),
    "sup_blur": dict(label="supervised + blur aug.", color="#E69F00"),
    "no_blur":  dict(label="no blur aug.", color="#0072B2"),
    "ijepa":    dict(label="I-JEPA (no hand-crafted aug.)", color="#009E73"),
    "unknown":  dict(label="augmentation unknown", color="#999999"),
}

ENC_STYLE = {   # the six method encoders: family colour plus a distinct marker and line style
    "dinov2_s14":   dict(color="#CC79A7", marker="o", ls="-"),
    "r50_barlow":   dict(color="#CC79A7", marker="s", ls="--"),
    "mae_b16":      dict(color="#0072B2", marker="^", ls="-"),
    "clip_b16":     dict(color="#0072B2", marker="D", ls="--"),
    "r50_sup":      dict(color="#0072B2", marker="v", ls=":"),
    "satlas_swinb": dict(color="#999999", marker="P", ls="-"),
}
UNFILLED = {"x", "+", "1", "2", "3", "4", "|", "_"}

def mlabel(k):
    return METHOD_STYLE.get(k, dict(label=k))["label"]

def mcolor(k):
    return METHOD_STYLE.get(k, dict(color="#444444"))["color"]

def mmarker(k):
    return METHOD_STYLE.get(k, dict(marker="o"))["marker"]

def plain_label(k):
    """Method label without mathtext (tick labels in tightly spaced rows): ATC@$\\hat{s}$ -> ATC@ŝ."""
    return mlabel(k).replace("$\\hat{s}$", "ŝ")

def scat(ax, x, y, color, marker, s=4.0, alpha=0.5, label=None, filled=True, **kw):
    """Scatter that keeps line-only markers visible (x, +, 1, ...) and supports open markers."""
    if marker in UNFILLED:
        return ax.scatter(x, y, s=s, marker=marker, color=color, linewidths=0.5, alpha=alpha, label=label, **kw)
    if not filled:
        return ax.scatter(x, y, s=s, marker=marker, facecolors="none", edgecolors=color, linewidths=0.5, alpha=alpha, label=label, **kw)
    return ax.scatter(x, y, s=s, marker=marker, color=color, linewidths=0, alpha=alpha, label=label, **kw)

def handle(color, marker, label, filled=True, ls="none", ms=4):
    return Line2D([], [], color=color, marker=marker, ls=ls, ms=ms, mfc=(color if filled else "white"), mec=color, label=label)

def no_data(ax, msg="no data in this run"):
    ax.text(0.5, 0.5, msg, transform=ax.transAxes, ha="center", va="center", fontsize=7, color="#666666")

def image_axes(ax):
    """Image panel: no ticks or spines; the x label stays available for a caption line."""
    ax.set_xticks([])
    ax.set_yticks([])
    for sp in ax.spines.values():
        sp.set_visible(False)

def err(mid, lo, hi):
    """Asymmetric error-bar array from a point and its interval (clipped at 0 so a biased bootstrap CI never errors)."""
    mid, lo, hi = (np.atleast_1d(np.asarray(v, float)) for v in (mid, lo, hi))
    return np.vstack([np.clip(mid - lo, 0, None), np.clip(hi - mid, 0, None)])

def ds_axis(ax, labels, n_rs):
    """Datasets on the y-axis, top to bottom; a thin divider separates the remote-sensing block from natural images."""
    n = len(labels)
    y = np.arange(n)[::-1].astype(float)
    ax.set_yticks(y)
    ax.set_yticklabels(labels)
    ax.set_ylim(-0.6, n - 0.4)
    if 0 < n_rs < n:
        ax.axhline(n - n_rs - 0.5, color="#AAAAAA", lw=0.4, zorder=0)
    return y

def _logfmt(v, p=None):
    if v <= 0:
        return ""
    k = np.log10(v)
    if abs(k - round(k)) < 1e-9:
        return f"{v:g}" if -3 <= round(k) <= 3 else f"$10^{{{int(round(k))}}}$"
    r = float(f"{v:.2g}")
    return f"{r:g}" if 1e-3 <= v < 1e5 else f"{v:.1e}"

def log_ticks(axis, lo, hi, fmt=None):
    """Readable log-axis ticks: decades when at least two fall inside [lo, hi] (at most five), otherwise three rounded
    geometric values; minor ticks unlabelled."""
    lo, hi = max(float(lo), 1e-300), max(float(hi), 1e-300)
    a, b = int(np.ceil(np.log10(lo) - 1e-9)), int(np.floor(np.log10(hi) + 1e-9))
    if b - a + 1 >= 2:
        step = max(1, int(np.ceil((b - a + 1) / 5)))
        ticks = [10.0 ** k for k in range(a, b + 1, step)]
    else:
        cand = [m * 10.0 ** k for k in range(a - 1, b + 2) for m in (1, 2, 5) if lo <= m * 10.0 ** k <= hi]
        if len(cand) >= 2:
            ticks = cand if len(cand) <= 4 else cand[::int(np.ceil(len(cand) / 4))]
        else:
            ticks = sorted(set(float(f"{v:.2g}") for v in np.geomspace(lo * 1.08, hi / 1.08, 3)))
            ticks = [t for t in ticks if lo <= t <= hi] or [float(f"{np.sqrt(lo * hi):.2g}")]
    axis.set_major_locator(FixedLocator(ticks))
    axis.set_minor_formatter(NullFormatter())
    axis.set_major_formatter(FuncFormatter(fmt or _logfmt))

def fix_log(ax, which="y"):
    """Apply log_ticks to an autoscaled log axis using its current view limits."""
    lo, hi = ax.get_ylim() if which == "y" else ax.get_xlim()
    log_ticks(ax.yaxis if which == "y" else ax.xaxis, min(lo, hi), max(lo, hi))

def panel_label(ax, s):
    """Bold 9-pt panel label, top-left outside the axes (identical placement in every figure)."""
    ax.set_title(s, loc="left", fontsize=9, fontweight="bold", pad=3)

def _drawn_ticklabels(axis):
    lo, hi = sorted(axis.get_view_interval())
    span = abs(hi - lo) or 1.0
    out = []
    for tk in axis.get_major_ticks() + axis.get_minor_ticks():
        loc = tk.get_loc()
        if loc is None or not np.isfinite(loc) or loc < lo - 1e-9 * span or loc > hi + 1e-9 * span:
            continue
        for lab in (tk.label1, tk.label2):
            if lab.get_visible() and lab.get_text().strip():
                out.append(lab)
    return out

def _all_texts(fig):
    """Every visible text of a figure: tick labels, axis labels, titles, annotations, legends, figure-level texts."""
    T = []
    for ax in fig.axes:
        if not ax.get_visible():
            continue
        if ax.axison:
            T += _drawn_ticklabels(ax.xaxis) + _drawn_ticklabels(ax.yaxis)
            for t in (ax.xaxis.label, ax.yaxis.label, ax.xaxis.get_offset_text(), ax.yaxis.get_offset_text()):
                if t.get_visible() and t.get_text().strip():
                    T.append(t)
        for t in (ax.title, ax._left_title, ax._right_title):
            if t.get_visible() and t.get_text().strip():
                T.append(t)
        T += [t for t in ax.texts if t.get_visible() and t.get_text().strip()]
        lg = ax.get_legend()
        if lg is not None and lg.get_visible():
            T += [t for t in lg.get_texts() if t.get_text().strip()]
            if lg.get_title().get_text().strip():
                T.append(lg.get_title())
    for lg in fig.legends:
        T += [t for t in lg.get_texts() if t.get_text().strip()]
        if lg.get_title().get_text().strip():
            T.append(lg.get_title())
    T += [t for t in fig.texts if t.get_visible() and t.get_text().strip()]
    for t in (getattr(fig, "_suptitle", None), getattr(fig, "_supxlabel", None), getattr(fig, "_supylabel", None)):
        if t is not None and t not in T and t.get_visible() and t.get_text().strip():
            T.append(t)
    return T

def check_figure(fig, design_w, strict=True, min_pt=6.5, tol_px=0.5):
    """Fail on text-text overlap, text outside the canvas, fonts below 6.5 pt, or width above the design width."""
    fig.canvas.draw()
    r = fig.canvas.get_renderer()
    W, H = fig.bbox.width, fig.bbox.height
    issues = []
    if fig.get_size_inches()[0] > design_w + 1e-6:
        issues.append(("width_above_design", float(fig.get_size_inches()[0]), design_w))
    boxes = []
    for t in _all_texts(fig):
        if t.get_fontsize() < min_pt - 1e-6:
            issues.append(("font_below_6.5pt", t.get_text()[:30], t.get_fontsize()))
        bb = t.get_window_extent(r)
        if bb.width <= 0 or bb.height <= 0:
            continue
        if bb.x0 < -tol_px or bb.y0 < -tol_px or bb.x1 > W + tol_px or bb.y1 > H + tol_px:
            issues.append(("outside_canvas", t.get_text()[:30]))
        boxes.append((t, bb))
    for i in range(len(boxes)):
        for j in range(i + 1, len(boxes)):
            a, b = boxes[i][1], boxes[j][1]
            if min(a.x1, b.x1) - max(a.x0, b.x0) > tol_px and min(a.y1, b.y1) - max(a.y0, b.y0) > tol_px:
                issues.append(("overlap", boxes[i][0].get_text()[:25], boxes[j][0].get_text()[:25]))
    if strict and issues:
        raise AssertionError(f"check_figure: {issues[:8]}")
    return issues

def thin_ticks(fig):
    """Remedy for crowded tick labels: fewer major ticks on every quantitative axis."""
    for ax in fig.axes:
        if not ax.axison:
            continue
        for axis, scale in ((ax.xaxis, ax.get_xscale()), (ax.yaxis, ax.get_yscale())):
            if isinstance(axis.get_major_locator(), FixedLocator):
                continue
            if scale == "log":
                axis.set_major_locator(LogLocator(base=10, numticks=4))
                axis.set_minor_formatter(NullFormatter())
            elif scale == "linear":
                axis.set_major_locator(MaxNLocator(nbins=3))

def finite(a):
    a = np.asarray(a, float)
    return a[np.isfinite(a)]

def place_labels(ax, xs, ys, texts, fontsize=6.5, offsets=((4, 3), (4, -9), (-4, 3), (-4, -9), (0, 6), (0, -11), (6, -3), (-6, -3))):
    """Greedy non-overlapping point labels (call last, when every panel exists); the layout is then frozen so the labels
    cannot move relative to each other. A label that cannot be placed without overlap is omitted."""
    fig = ax.figure
    fig.canvas.draw()
    r = fig.canvas.get_renderer()
    placed = [t.get_window_extent(r) for t in _all_texts(fig)]
    for x, y, s in zip(xs, ys, texts):
        if not (np.isfinite(x) and np.isfinite(y)):
            continue
        for dx, dy in offsets:
            t = ax.annotate(s, (x, y), xytext=(dx, dy), textcoords="offset points", fontsize=fontsize,
                            ha="left" if dx >= 0 else "right", va="bottom")
            bb = t.get_window_extent(r)
            axbb = ax.get_window_extent(r)
            inside = bb.x0 >= axbb.x0 - 2 and bb.x1 <= axbb.x1 + 2 and bb.y0 >= axbb.y0 - 2 and bb.y1 <= axbb.y1 + 2
            clash = any(min(bb.x1, p.x1) - max(bb.x0, p.x0) > 0 and min(bb.y1, p.y1) - max(bb.y0, p.y0) > 0 for p in placed)
            if inside and not clash:
                placed.append(bb)
                break
            t.remove()
    freeze_layout(fig)

FIGS = {}

def _texts_outside(fig, tol_px=0.5):
    r = fig.canvas.get_renderer()
    W, H = fig.bbox.width, fig.bbox.height
    for t in _all_texts(fig):
        bb = t.get_window_extent(r)
        if bb.width > 0 and (bb.x0 < -tol_px or bb.y0 < -tol_px or bb.x1 > W + tol_px or bb.y1 > H + tol_px):
            return True
    return False

def freeze_layout(fig):
    """Run the constrained layout once and fix it: constrained layout is iterative, so without this every further draw
    (checks, PDF, PNG) would move elements slightly and the notebook and plot_figures.py copies could differ. If a text
    still sticks out of the canvas (layout differences across matplotlib versions), the layout pads grow before freezing."""
    fig.canvas.draw()
    eng = fig.get_layout_engine() if hasattr(fig, "get_layout_engine") else None
    for pad in (6.0, 9.0, 12.0):
        if eng is None or not hasattr(eng, "set") or not _texts_outside(fig):
            break
        eng.set(w_pad=pad / 72.0, h_pad=pad / 72.0)
        fig.canvas.draw()
    try:
        fig.set_layout_engine("none")
    except AttributeError:
        fig.set_constrained_layout(False)

def figure(stem):
    """Register a renderer; data["_thin"] (set by the notebook when the first check needed it) thins crowded ticks.
    The layout is frozen after one draw, so the notebook and the standalone script save identical figures."""
    def deco(fn):
        def wrapped(d):
            fig = fn(d)
            if d.get("_thin"):
                thin_ticks(fig)
            freeze_layout(fig)
            return fig
        wrapped.__name__ = fn.__name__
        FIGS[stem] = wrapped
        return wrapped
    return deco

# ---------------------------------------------------------------- Figure 4: method schematic
@figure("fig4_method")
def fig4_method(d):
    fig, ax = plt.subplots(figsize=d["figsize"])
    ax.set_axis_off()
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    fill = dict(data="#F2F2F2", pixel="#FBE3D6", model="#D6E6F4", warn="#FFF1CC")
    edge = dict(data="#555555", pixel=OURS_COLOR, model="#0072B2", warn="#B58900")
    pos = {}
    for b in d["boxes"]:
        (x, y), (w, h) = b["xy"], b["wh"]
        ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.004,rounding_size=0.02", fc=fill[b["kind"]], ec=edge[b["kind"]], lw=0.7))
        ax.text(x + w / 2, y + h / 2, b["text"], ha="center", va="center", fontsize=6.5, linespacing=1.15)
        pos[b["id"]] = (x, y, w, h)
    for a, b, lab in d["arrows"]:
        xa, ya, wa, ha = pos[a]
        xb, yb, wb, hb = pos[b]
        cs = "arc3,rad=0"
        if abs(ya - yb) < 1e-6:
            start, end = ((xa + wa, ya + ha / 2), (xb, yb + hb / 2)) if xb > xa else ((xa, ya + ha / 2), (xb + wb, yb + hb / 2))
        elif abs(xa - xb) < 1e-6:
            start, end = (xa + wa / 2, ya), (xb + wb / 2, yb + hb)
        else:
            start, end = (xa + wa / 2, ya), (xb, yb + hb / 2)
            cs = "angle,angleA=-90,angleB=180,rad=0"
        ax.annotate("", xy=end, xytext=start, arrowprops=dict(arrowstyle="-|>", lw=0.7, color="#333333", shrinkA=1, shrinkB=1,
                                                              connectionstyle=cs, mutation_scale=7))
        if lab:
            mx, my = (start[0] + end[0]) / 2, (start[1] + end[1]) / 2
            ax.text(mx + (0.012 if abs(start[0] - end[0]) < 1e-6 else 0.0), my + (0.018 if abs(start[1] - end[1]) < 1e-6 else 0.0),
                    lab, fontsize=6.5, ha="left" if abs(start[0] - end[0]) < 1e-6 else "center", va="bottom" if abs(start[1] - end[1]) < 1e-6 else "center",
                    style="italic", color="#333333")
    handles = [Patch(fc=fill[k], ec=edge[k], lw=0.7, label=l) for l, k in d["legend"]]
    ax.legend(handles=handles, loc="lower left", bbox_to_anchor=(0.0, -0.02), fontsize=6.5, handlelength=1.2, borderaxespad=0.2)
    return fig

def cbar_ticks(cb, lo, hi, log):
    """At most four readable colour-bar ticks (fixed positions when the range is under one decade)."""
    ax = cb.ax.yaxis if cb.orientation == "vertical" else cb.ax.xaxis
    if log and hi / max(lo, 1e-300) >= 10:
        ax.set_major_locator(LogLocator(base=10, numticks=4))
    else:
        t = np.geomspace(lo, hi, 3) if log else np.linspace(lo, hi, 3)
        t = [float(f"{v:.2g}") for v in t]
        t = [v for v in t if lo <= v <= hi] or [float(f"{lo:.2g}")]
        ax.set_major_locator(FixedLocator(t))
        ax.set_major_formatter(FuncFormatter(lambda v, p: f"{v:g}"))
    ax.set_minor_formatter(NullFormatter())

def hbox(ax, data, pos, **kw):
    """Horizontal box plot across matplotlib versions (orientation= since 3.10, vert= before)."""
    try:
        return ax.boxplot(data, positions=pos, orientation="horizontal", **kw)
    except TypeError:
        return ax.boxplot(data, positions=pos, vert=False, **kw)

def dot_rows(ax, y, series, n_rows):
    """Rows of points with horizontal CIs; series entries may vary colour/marker/label per row."""
    hs = {}
    for s in series:
        x, lo, hi = (np.asarray(s[k], float) for k in ("x", "lo", "hi"))
        cols = s.get("colors") or [s["color"]] * n_rows
        mks = s.get("markers") or [s["marker"]] * n_rows
        labs = s.get("labels") or [s["label"]] * n_rows
        filled = s.get("filled", True)
        for k in range(n_rows):
            if not np.isfinite(x[k]):
                continue
            mfc = cols[k] if (filled and mks[k] not in UNFILLED) else ("white" if mks[k] not in UNFILLED else cols[k])
            ax.errorbar([x[k]], [y[k] + s.get("dy", 0.0)], xerr=err(x[k], lo[k], hi[k]), fmt=mks[k], ms=s.get("ms", 3.4),
                        color=cols[k], mfc=mfc, mec=cols[k], mew=0.8, lw=0.7, capsize=1.2, zorder=3)
            hs.setdefault(labs[k], handle(cols[k], mks[k], labs[k], filled=filled))
    return hs

# ---------------------------------------------------------------- Figure 1: teaser
@figure("fig1_teaser")
def fig1_teaser(d):
    fig = plt.figure(figsize=d["figsize"])
    gs = fig.add_gridspec(1, 4, width_ratios=[1.55, 1, 1, 1])
    a, b, c, e = (fig.add_subplot(gs[0, i]) for i in range(4))
    hs = []
    A = d.get("a")
    if A:
        imgs = [np.asarray(im, np.uint8) for im in A["imgs"]]
        h, w, gap = imgs[0].shape[0], imgs[0].shape[1], 12
        strip = np.full((h, len(imgs) * w + gap * (len(imgs) - 1), 3), 255, np.uint8)
        for i, im in enumerate(imgs):
            strip[:, i * (w + gap):i * (w + gap) + w] = im
        a.imshow(strip, interpolation="none")
        a.set_anchor("N")                                   # top-aligned, so the panel label lines up with (b)-(d)
        box = dict(boxstyle="round,pad=0.15", fc="black", ec="none", alpha=0.55)
        for i, (top, bot) in enumerate(zip(A["top"], A["bottom"])):
            x0 = i * (w + gap)
            a.text(x0 + 8, 10, top, ha="left", va="top", fontsize=6.5, color="white", bbox=box)
            if bot:
                a.text(x0 + 8, h - 10, bot, ha="left", va="bottom", fontsize=6.5, color="white", bbox=box)
        a.set_xlabel(A["xlabel"])
    else:
        no_data(a, d.get('missing_msg', 'no data in this run'))
    image_axes(a)
    panel_label(a, "(a)")
    B = d.get("b")
    if B:
        eta = np.asarray(B["eta"], float)
        for s in B["series"]:
            q = np.asarray(s["q"], float)
            b.fill_between(eta, q[0], q[2], color=s["color"], alpha=0.18, lw=0)
            ln, = b.plot(eta, q[1], color=s["color"], ls=s["ls"], marker=s["marker"], markevery=7, ms=2.8, label=s["label"])
            b.axvline(s["knee"], color=s["color"], ls=":", lw=0.8)
            hs.append(ln)
        b.set_xscale("log")
        log_ticks(b.xaxis, eta.min(), eta.max())
        b.set_xlim(eta.min(), eta.max())
        b.set_ylim(0, 1)
        b.set_xlabel("re-blur $\\eta$ (px$^2$, native grid)")
        b.set_ylabel("$\\rho(\\eta)$")
    else:
        no_data(b, d.get('missing_msg', 'no data in this run'))
    panel_label(b, "(b)")
    C = d.get("c")
    if C and len(C["truth"]):
        t = np.asarray(C["truth"], float)
        for s in C["series"]:
            scat(c, t, np.asarray(s["pred"], float), s["color"], s["marker"], s=3.0, alpha=0.45, rasterized=True)
            hs.append(handle(s["color"], s["marker"], s["label"]))
        c.plot([0, 1], [0, 1], color="black", lw=0.6, ls="--")
        c.set_xlim(0, 1)
        c.set_ylim(0, 1)
        c.set_xlabel("true accuracy (unflagged cells)")
        c.set_ylabel("predicted accuracy")
    else:
        no_data(c)
    panel_label(c, "(c)")
    D = d.get("d")
    if D:
        floor = float(D["floor"])
        for i, g in enumerate(D["groups"]):
            p = np.clip(np.asarray(g["p"], float), floor, 1.0)
            scat(e, i + np.asarray(g["jitter"], float), p, g["color"], g["marker"], s=7, alpha=0.7, rasterized=True)
        e.set_yscale("log")
        e.set_ylim(floor / 4, 4)
        e.axhline(D["alpha"], color="black", ls="--", lw=0.7)
        hs.append(Line2D([], [], color="black", ls="--", lw=0.7, label=f"GOF $\\alpha$ = {D['alpha']:g}"))
        e.set_xlim(-0.6, 1.6)
        e.set_xticks([0, 1])
        e.set_xticklabels([g["label"] for g in D["groups"]])
        k0 = int(round(np.log10(floor)))
        step = max(1, int(np.ceil(-k0 / 4)))
        e.yaxis.set_major_locator(FixedLocator([10.0 ** k for k in range(k0, 1, step)]))
        e.yaxis.set_minor_locator(FixedLocator([]))
        clipped = bool(D.get("clipped"))
        e.yaxis.set_major_formatter(FuncFormatter(lambda v, p: "1" if abs(v - 1) < 1e-12 else
                                                  (f"$\\leq\\!10^{{{int(round(np.log10(v)))}}}$" if (clipped and abs(v - floor) < 1e-6 * floor)
                                                   else f"$10^{{{int(round(np.log10(v)))}}}$")))
        e.set_ylabel("GOF $p$-value (in-family)")
    else:
        no_data(e, d.get('missing_msg', 'no data in this run'))
    panel_label(e, "(d)")
    if hs:
        fig.legend(handles=hs, loc="outside lower center", ncol=3, handlelength=1.6, columnspacing=1.2)
    return fig

# ---------------------------------------------------------------- Figure 2: physics on LandCover.ai
@figure("fig2_physics")
def fig2_physics(d):
    fig, axs = plt.subplots(2, 3, figsize=d["figsize"])
    (a, b, c), (dd, e, f) = axs
    M = d.get("maps")
    if M:
        a.imshow(np.asarray(M["thumb"], np.uint8), interpolation="none")
        a.set_xlabel(M["label"])
        for ax, key, cmap, lab, logn in ((b, "O", "viridis", "$O_x$ (px$^{-2}$)", False),
                                         (c, "knee", "cividis", "$s_{\\mathrm{raw}}$ (px$^2$)", True)):
            Z = np.asarray(M[key], float)
            cm = plt.get_cmap(cmap).copy()
            cm.set_bad("#DDDDDD")
            fz = finite(Z)
            fz = fz[fz > 0] if logn else fz
            if len(fz) == 0:
                no_data(ax, d.get('missing_msg', 'no data in this run'))
                continue
            lo, hi = float(fz.min()), float(fz.max())
            hi = hi if hi > lo else lo * 1.5 + 1e-12
            norm = LogNorm(vmin=lo, vmax=hi) if logn else mpl.colors.Normalize(vmin=lo, vmax=hi)
            im = ax.imshow(np.ma.masked_invalid(Z), cmap=cm, norm=norm, interpolation="none")
            cb = fig.colorbar(im, ax=ax, fraction=0.07, pad=0.03)
            cb.set_label(lab)
            cbar_ticks(cb, lo, hi, logn)
            ax.set_xlabel("per-tile map (224-px tiles)")
    else:
        for ax in (a, b, c):
            no_data(ax, d.get('missing_msg', 'no data in this run'))
    for ax, lab in zip((a, b, c), ("(a)", "(b)", "(c)")):
        image_axes(ax)
        panel_label(ax, lab)
    hs = []
    Cl = d.get("collapse")
    if Cl and len(Cl["u"]):
        u, r = np.asarray(Cl["u"], float), np.asarray(Cl["rho"], float)
        ok = np.isfinite(u) & np.isfinite(r) & (u > 0)
        hb = dd.hexbin(u[ok], r[ok], xscale="log", gridsize=30, norm=LogNorm(), cmap="viridis", mincnt=1, linewidths=0, rasterized=True)
        cb = fig.colorbar(hb, ax=dd, fraction=0.07, pad=0.03)
        cb.set_label("count (tiles $\\times$ levels)")
        cb.ax.yaxis.set_minor_formatter(NullFormatter())
        uu = np.geomspace(u[ok].min(), u[ok].max(), 200)
        g = float(Cl["gamma_med"])
        dd.plot(uu, 1 - (1 + uu) ** (-g), color="white", lw=2.0)
        hs += dd.plot(uu, 1 - (1 + uu) ** (-g), color="black", lw=0.9, ls="--", label=f"(d) $1-(1+u)^{{-\\hat\\gamma}}$, $\\hat\\gamma$ = {g:.2f}")
        hs.append(dd.axvline(1.0, color="#D55E00", lw=0.9, ls=":", label="(d) $u = 1$, i.e. $\\eta = \\hat{s}$"))
        dd.set_xlim(u[ok].min(), u[ok].max())
        log_ticks(dd.xaxis, u[ok].min(), u[ok].max())
        dd.set_ylim(0, 1)
        dd.set_xlabel("$u = \\eta / \\hat{s}$")
        dd.set_ylabel("$\\rho(\\eta)$")
    else:
        no_data(dd, d.get('missing_msg', 'no data in this run'))
    panel_label(dd, "(d)")
    K = d.get("knee_law")
    if K:
        s0, med, q1, q3 = (np.asarray(K[k], float) for k in ("s0", "med", "q1", "q3"))
        e.errorbar(s0, med, yerr=err(med, q1, q3), fmt="o", color="#0072B2", ms=3.2, lw=0.8, capsize=1.5)
        hs.append(handle("#0072B2", "o", "(e) per-tile knee: median, IQR"))
        xx = np.array([0.0, s0.max()])
        hs += e.plot(xx, K["intercept"] + xx, color="black", ls="-.", lw=0.7, label="(e) slope 1 reference")
        e.text(0.04, 0.97, K["annot"], transform=e.transAxes, ha="left", va="top", fontsize=6.5)
        e.set_xlabel("applied blur $s_0$ (px$^2$)")
        e.set_ylabel("knee $s_{\\mathrm{raw}}$ (px$^2$)")
    else:
        no_data(e, d.get('missing_msg', 'no data in this run'))
    panel_label(e, "(e)")
    Fw = d.get("fwhm")
    if Fw:
        y = np.array([Fw["fw25"], Fw["fw50"]], float)
        lo = np.array([Fw["ci25"][0], Fw["ci50"][0]], float)
        hi = np.array([Fw["ci25"][1], Fw["ci50"][1]], float)
        f.errorbar([0, 1], y, yerr=err(y, lo, hi), fmt="s", color="#009E73", ms=3.6, lw=0.9, capsize=2.0)
        hs.append(handle("#009E73", "s", "(f) effective FWHM, 95% CI"))
        hs.append(f.axhline(2.0 * Fw["fw25"], color="black", ls=":", lw=0.8, label="(f) nominal ratio: 2 $\\times$ FWHM(25 cm)"))
        f.set_xlim(-0.6, 1.6)
        f.set_ylim(0, max(np.nanmax(hi), 2.0 * Fw["fw25"]) * 1.25)
        f.set_xticks([0, 1])
        f.set_xticklabels(["25 cm", "50 cm"])
        f.set_xlabel(Fw["annot"])
        f.set_ylabel("effective FWHM (m)")
    else:
        no_data(f, d.get('missing_msg', 'no data in this run'))
    panel_label(f, "(f)")
    if hs:
        fig.legend(handles=hs, loc="outside lower center", ncol=3, handlelength=1.8, columnspacing=1.2)
    return fig

# ---------------------------------------------------------------- Figure 3: mechanism screen
@figure("fig3_mechanism")
def fig3_mechanism(d):
    fig, ax = plt.subplots(figsize=d["figsize"])
    rows = d.get("rows") or []
    if not rows:
        no_data(ax)
        return fig
    n = len(rows)
    y = np.arange(n)[::-1].astype(float)
    for yi, r in zip(y, rows):
        col = FAMILY_STYLE[r["family"]]["color"]
        for key, dy, filled in (("lc", 0.18, True), ("r45", -0.18, False)):
            v = r.get(key)
            if not v or v[0] is None or not np.isfinite(v[0]):
                continue
            ax.errorbar([v[0]], [yi + dy], xerr=err(v[0], v[1], v[2]), fmt="o", ms=3.0, color=col, mfc=(col if filled else "white"),
                        mec=col, mew=0.8, lw=0.7, capsize=1.2)
    for t in d["thresholds"]:
        ax.axvline(t, color="#555555", ls="--", lw=0.6, zorder=0)
    fams = [r["family"] for r in rows]
    for i in range(1, n):
        if fams[i] != fams[i - 1]:
            ax.axhline(y[i] + 0.5, color="#CCCCCC", lw=0.5, zorder=0)
    ax.set_yticks(y)
    ax.set_yticklabels([r["display"] for r in rows])
    ax.tick_params(axis="y", length=0)
    ax.set_ylim(-0.7, n - 0.3)
    ax.set_xlim(*d["xlim"])
    ax.set_xlabel("knee $\\rho$ (Spearman of feature knee vs. $s_0$)")
    hs = [handle("#333333", "o", d["ds_labels"][0], True), handle("#333333", "o", d["ds_labels"][1], False)]
    hs += [Patch(fc=FAMILY_STYLE[f_]["color"], ec="none", label=FAMILY_STYLE[f_]["label"]) for f_ in d["families"]]
    fig.legend(handles=hs, loc="outside lower center", ncol=2, handlelength=1.0, columnspacing=0.8)
    return fig

# ---------------------------------------------------------------- Figure 5: main results
@figure("fig5_main_results")
def fig5_main_results(d):
    fig, axs = plt.subplots(1, 3, figsize=d["figsize"], sharey=True)
    labels = d.get("datasets") or []
    if not labels:
        for ax, lab in zip(axs, ("(a)", "(b)", "(c)")):
            no_data(ax)
            panel_label(ax, lab)
        return fig
    n = len(labels)
    y = ds_axis(axs[0], labels, d["n_rs"])
    hs = {}
    for k, (ax, P) in enumerate(zip(axs, d["panels"])):
        if k:
            ax.tick_params(labelleft=False)
            if 0 < d["n_rs"] < n:
                ax.axhline(n - d["n_rs"] - 0.5, color="#AAAAAA", lw=0.4, zorder=0)
        if P.get("link"):
            s1, s2 = P["series"][P["link"][0]], P["series"][P["link"][1]]
            for i in range(n):
                if np.isfinite(s1["x"][i]) and np.isfinite(s2["x"][i]):
                    ax.plot([s1["x"][i], s2["x"][i]], [y[i] + s1["dy"], y[i] + s2["dy"]], color="#BBBBBB", lw=0.8, zorder=1)
        order = [i for i, s_ in enumerate(P["series"]) if s_.get("label") != P.get("top")] + \
                [i for i, s_ in enumerate(P["series"]) if s_.get("label") == P.get("top")]
        for lab_, h_ in dot_rows(ax, y, [P["series"][i] for i in order], n).items():
            hs.setdefault(lab_, h_)
        ax.set_xlim(*P["xlim"])
        ax.set_xlabel(P["xlabel"])
        if P.get("note"):
            ax.set_title(P["note"], loc="right", fontsize=7)
        panel_label(ax, "(" + "abc"[k] + ")")
    first = [k_ for k_ in d.get("legend_first", []) if k_ in hs]
    keys = first + sorted(k_ for k_ in hs if k_ not in first)
    fig.legend(handles=[hs[k_] for k_ in keys], loc="outside lower center", ncol=min(5, len(keys)), handlelength=1.2, columnspacing=1.0)
    return fig

# ---------------------------------------------------------------- Figure S1: theory checks
@figure("figS1_theory_checks")
def figS1_theory_checks(d):
    fig, axs = plt.subplots(1, 4, figsize=d["figsize"])
    a, b, c, e = axs
    hs1 = []
    R1 = d.get("r1")
    if R1 and len(R1["an"]):
        x, yv = np.abs(np.asarray(R1["fd"], float)), np.abs(np.asarray(R1["an"], float))
        ok = (x > 0) & (yv > 0) & np.isfinite(x) & np.isfinite(yv)
        a.scatter(x[ok], yv[ok], s=2, color="#0072B2", linewidths=0, alpha=0.5, rasterized=True)
        lo, hi = min(x[ok].min(), yv[ok].min()), max(x[ok].max(), yv[ok].max())
        a.plot([lo, hi], [lo, hi], color="black", ls="--", lw=0.6)
        a.set_xscale("log")
        a.set_yscale("log")
        log_ticks(a.xaxis, lo, hi)
        log_ticks(a.yaxis, lo, hi)
        a.text(0.04, 0.97, R1["annot"], transform=a.transAxes, ha="left", va="top", fontsize=6.5)
        a.set_xlabel("finite diff. $|\\partial_{s_0}\\rho|$")
        a.set_ylabel("closed form $|\\partial_{s_0}\\rho|$")
    else:
        no_data(a)
    panel_label(a, "(a)")
    R2 = d.get("r2")
    if R2:
        s = np.asarray(R2["s"], float)
        for cur in R2["curves"]:
            b.plot(s, np.maximum(np.asarray(cur["values"], float), 1e-17), color=cur["color"], marker=cur["marker"], ls=cur["ls"], ms=2.8, label=cur["label"])
        b.axhline(R2["tol"], color="black", ls=":", lw=0.7)
        b.text(s.max(), R2["tol"] / 4, "tolerance", ha="right", va="top", fontsize=6.5)
        b.set_xscale("log")
        b.set_yscale("log")
        log_ticks(b.xaxis, s.min(), s.max())
        b.set_ylim(1e-17, 10)
        b.yaxis.set_major_locator(FixedLocator([1e-15, 1e-10, 1e-5, 1.0]))
        b.yaxis.set_minor_formatter(NullFormatter())
        b.yaxis.set_major_formatter(FuncFormatter(lambda v, p: "1" if v == 1 else f"$10^{{{int(round(np.log10(v)))}}}$"))
        hs1 = [Line2D([], [], color=c_["color"], marker=c_["marker"], ls=c_["ls"], ms=2.8, label=c_["label"]) for c_ in R2["curves"]]
        b.set_xlabel("blur $s$ (px$^2$)")
        b.set_ylabel("$\\max|NT_sx - Nx|$")
    else:
        no_data(b)
    panel_label(b, "(b)")
    H = d.get("half")
    if H and H["groups"]:
        allv = []
        for g in H["groups"]:
            m = np.asarray(g["measured"], float)
            xs = g["predicted"] * np.exp(0.03 * (np.arange(len(m)) - (len(m) - 1) / 2))
            c.plot(xs, m, ls="none", marker=g["marker"], color=g["color"], ms=3.2, label=g["label"])
            allv += list(m) + [g["predicted"]]
        allv = finite(allv)
        lo, hi = allv.min() / 1.3, allv.max() * 1.3
        c.plot([lo, hi], [lo, hi], color="black", ls="--", lw=0.6)
        c.set_xscale("log")
        c.set_yscale("log")
        c.set_xlim(lo, hi)
        c.set_ylim(lo, hi)
        for ax_ in (c.xaxis, c.yaxis):
            ax_.set_major_locator(FixedLocator([0.5, 1, 2, 4]))
            ax_.set_minor_formatter(NullFormatter())
            ax_.set_major_formatter(FuncFormatter(lambda v, p: f"{v:g}"))
        c.legend(loc="upper left", handlelength=1.0)
        c.set_xlabel("predicted $2^{1/\\gamma}-1$")
        c.set_ylabel("measured $\\eta_{1/2}/s_0$")
    else:
        no_data(c)
    panel_label(c, "(c)")
    P5 = d.get("prop5")
    if P5 and P5["groups"]:
        allv = []
        for g in P5["groups"]:
            bx, dy = np.asarray(g["bound"], float), np.asarray(g["drift"], float)
            ok = (bx > 0) & (dy > 0)
            scat(e, bx[ok], dy[ok], g["color"], g["marker"], s=2.5, alpha=0.5, rasterized=True)
            allv += list(bx[ok]) + list(dy[ok])
        allv = finite(allv)
        lo, hi = allv.min(), allv.max()
        e.plot([lo, hi], [lo, hi], color="black", ls="--", lw=0.6)
        e.set_xscale("log")
        e.set_yscale("log")
        log_ticks(e.xaxis, lo, hi)
        log_ticks(e.yaxis, lo, hi)
        hs1 += [handle(g["color"], g["marker"], g["label"]) for g in P5["groups"]]
        e.set_xlabel("Prop. 5 bound\n(" + P5["annot"] + ")")
        e.set_ylabel("measured drift")
    else:
        no_data(e)
    panel_label(e, "(d)")
    if hs1:
        fig.legend(handles=hs1, loc="outside lower center", ncol=len(hs1), handlelength=1.6, columnspacing=1.5)
    return fig

# ---------------------------------------------------------------- Figure S2: certificate
@figure("figS2_certificate")
def figS2_certificate(d):
    fig, axs = plt.subplots(1, 3, figsize=d["figsize"])
    a, b, c = axs
    st = {"Hoeffding": dict(color="#0072B2", marker="o", ls="-"), "EB": dict(color="#E69F00", marker="s", ls="--")}
    hs = []
    B = d.get("bounds") or {}
    for name, S in B.items():
        s_ = st[name]
        n = np.asarray(S["n"], float)
        ln, = a.plot(n, S["cov_med"], color=s_["color"], marker=s_["marker"], ls=s_["ls"], ms=3, label=f"{name}: median")
        ln2, = a.plot(n, S["cov_min"], color=s_["color"], marker=s_["marker"], ls=":", ms=2.6, mfc="white", label=f"{name}: minimum")
        hs += [ln, ln2]
        for ax_, key in ((a, "all_cov"), (b, "all_diam"), (c, "all_width")):
            xa, ya = np.asarray(S["all_n"], float), np.asarray(S[key], float)
            ok = np.isfinite(xa) & np.isfinite(ya) & ((ya > 0) if ax_ is not a else True)
            ax_.scatter(xa[ok], ya[ok], s=5, marker=s_["marker"], facecolors="none", edgecolors=s_["color"], linewidths=0.5)
        dm, wm = np.asarray(S["diam_med"], float), np.asarray(S["width_med"], float)
        b.plot(n[dm > 0], dm[dm > 0], color=s_["color"], marker=s_["marker"], ls=s_["ls"], ms=3)
        c.plot(n, wm, color=s_["color"], marker=s_["marker"], ls=s_["ls"], ms=3)
    if B:
        a.axhline(1 - d["delta"], color="black", ls="--", lw=0.7)
        a.axhline(d["min_cov"], color="black", ls=":", lw=0.7)
        hs += [Line2D([], [], color="black", ls="--", lw=0.7, label=f"$1-\\delta$ = {1 - d['delta']:.2f}"),
               Line2D([], [], color="black", ls=":", lw=0.7, label=f"R8 threshold {d['min_cov']:.2f}"),
               handle("#555555", "o", "$n_Q$ = all (per dataset)", filled=False)]
        nom = sorted({float(v) for S in B.values() for v in S["n"]})
        for ax_ in (a, b, c):
            ax_.set_xscale("log")
            ax_.set_xlim(*d["xlim"])
            ax_.xaxis.set_major_locator(FixedLocator(nom))
            ax_.xaxis.set_major_formatter(FuncFormatter(lambda v, p: f"{v:g}"))
            ax_.xaxis.set_minor_formatter(NullFormatter())
            ax_.set_xlabel("target size $n_Q$")
        a.set_ylim(max(0.0, min(d["min_cov"], np.nanmin([np.nanmin(S["cov_min"]) for S in B.values()])) - 0.05), 1.01)
        a.set_ylabel("coverage of $C$")
        ref = d.get("ref")
        if ref:
            xx = np.asarray(ref["n"], float)
            b.plot(xx, ref["y0"] * (xx / xx[0]) ** -0.5, color="black", ls="--", lw=0.7)
            hs.append(Line2D([], [], color="black", ls="--", lw=0.7, label="slope $-1/2$"))
        b.set_yscale("log")
        fix_log(b)
        b.set_ylabel("diam $CS$ (px$^2$)")
        c.set_yscale("log")
        fix_log(c)
        c.set_ylabel("width of $C$ (accuracy)")
        fig.legend(handles=hs, loc="outside lower center", ncol=4, handlelength=1.6, columnspacing=1.0)
    else:
        for ax_ in axs:
            no_data(ax_)
    for ax_, lab in zip(axs, ("(a)", "(b)", "(c)")):
        panel_label(ax_, lab)
    return fig

# ---------------------------------------------------------------- Figure S3: statistics and seeds
@figure("figS3_statistics_seeds")
def figS3_statistics_seeds(d):
    fig, axs = plt.subplots(1, 3, figsize=d["figsize"])
    a, b, c = axs
    hs = []
    A = d.get("paired")
    if A and A["datasets"]:
        y = ds_axis(a, A["datasets"], A["n_rs"])
        data, pos = [], []
        for yi, vals, jit in zip(y, A["diffs"], A["jitter"]):
            v = np.asarray(vals, float)
            if len(v):
                a.scatter(v, yi + np.asarray(jit, float), s=2, color="#D55E00", alpha=0.35, linewidths=0, rasterized=True)
                data.append(v)
                pos.append(yi)
        if data:
            hbox(a, data, pos, widths=0.55, showfliers=False, manage_ticks=False, medianprops=dict(color="black", lw=0.9),
                 boxprops=dict(lw=0.6), whiskerprops=dict(lw=0.6), capprops=dict(lw=0.6))
        a.axvline(0, color="black", lw=0.6, ls="--")
        a.set_xlabel("$\\Delta$ error, ours $-$ best (pp)")
    else:
        no_data(a)
    panel_label(a, "(a)")
    B = d.get("seeds")
    if B and B["groups"]:
        xt, xl, seen = [], [], set()
        for j, g in enumerate(B["groups"]):
            xs = j * (len(g["seeds"]) + 1.5) + np.arange(len(g["seeds"]))
            for s in g["series"]:
                b.plot(xs, s["vals"], color=s["color"], marker=s["marker"], ms=3, lw=1.6 if s["key"] == "ours" else 0.9,
                       ls=s.get("ls", "-"), mfc=s["color"] if s["marker"] not in UNFILLED else None)
                if s["key"] not in seen:
                    seen.add(s["key"])
                    hs.append(handle(s["color"], s["marker"], s["legend"], ls=s.get("ls", "-")))
            xt.append(float(xs.mean()))
            xl.append(g["label"])
        b.set_xticks(xt)
        b.set_xticklabels(xl)
        b.set_ylabel("unflagged MAE (pp)")
        b.set_xlabel(B["xlabel"])
    else:
        no_data(b, "multi-seed data missing")
    panel_label(b, "(b)")
    C = d.get("signflip")
    if C and len(C["null"]):
        null = np.asarray(C["null"], float)
        c.hist(null, bins=min(40, max(5, len(np.unique(null)))), color="#BBBBBB", edgecolor="none")
        c.axvline(C["obs"], color="#D55E00", lw=1.5)
        hs.append(Line2D([], [], color="#D55E00", lw=1.5, label=C["label"]))
        c.set_xlabel("mean $\\Delta$ over datasets (pp)")
        c.set_ylabel("sign patterns")
    else:
        no_data(c)
    panel_label(c, "(c)")
    if hs:
        fig.legend(handles=hs, loc="outside lower center", ncol=min(4, len(hs)), handlelength=1.6, columnspacing=1.2)
    return fig

# ---------------------------------------------------------------- Figure S4: encoder breakdown
@figure("figS4_encoder_breakdown")
def figS4_encoder_breakdown(d):
    fig = plt.figure(figsize=d["figsize"])
    gs = fig.add_gridspec(1, 2, width_ratios=[5.2, 1.0])
    a, b = fig.add_subplot(gs[0, 0]), fig.add_subplot(gs[0, 1])
    Z = np.asarray(d["delta"], float) if d.get("datasets") else np.zeros((0, 0))
    if Z.size == 0 or not np.isfinite(Z).any():
        no_data(a)
        no_data(b)
        panel_label(a, "(a)")
        panel_label(b, "(b)")
        return fig
    v = max(float(np.nanmax(np.abs(Z))), 0.1)
    im = a.imshow(Z, cmap="RdBu_r", norm=TwoSlopeNorm(vcenter=0.0, vmin=-v, vmax=v), aspect="auto", interpolation="none")
    for i in range(Z.shape[0]):
        for j in range(Z.shape[1]):
            if np.isfinite(Z[i, j]):
                a.text(j, i, f"{Z[i, j]:+.1f}", ha="center", va="center", fontsize=6.5, color="white" if abs(Z[i, j]) > 0.6 * v else "black")
    a.set_yticks(range(len(d["datasets"])))
    a.set_yticklabels(d["datasets"])
    a.set_xticks(range(len(d["enc_labels"])))
    a.set_xticklabels(d["enc_labels"])
    a.tick_params(length=0)
    for sp in a.spines.values():
        sp.set_visible(False)
    if 0 < d["n_rs"] < Z.shape[0]:
        a.axhline(d["n_rs"] - 0.5, color="black", lw=0.8)
    cb = fig.colorbar(im, ax=a, fraction=0.035, pad=0.015)
    cb.set_label("$\\Delta$ MAE, ours $-$ best (pp)")
    cb.ax.yaxis.set_major_locator(MaxNLocator(5))
    w = np.asarray(d["wins_ds"], float)
    b.barh(np.arange(len(w)), w, color="#D55E00", height=0.6)
    b.set_ylim(len(w) - 0.5, -0.5)
    b.set_yticks(range(len(w)))
    b.set_yticklabels([])
    b.tick_params(axis="y", length=0)
    b.set_xlim(0, d["n_enc"])
    b.xaxis.set_major_locator(FixedLocator(list(range(0, d["n_enc"] + 1, 2))))
    b.set_xlabel("encoders won")
    panel_label(a, "(a)")
    panel_label(b, "(b)")
    return fig

# ---------------------------------------------------------------- Figure S8: accuracy curves
@figure("figS8_accuracy_curves")
def figS8_accuracy_curves(d):
    fig, axs = plt.subplots(2, 5, figsize=d["figsize"], sharex=True, sharey=True)
    hs = {}
    panels = d.get("panels") or []
    for k, ax in enumerate(axs.ravel()):
        if k >= len(panels):
            ax.set_axis_off()                                  # unused slot: blank, but keeps the full figure width
            continue
        P = panels[k]
        for cv in P["curves"]:
            st = ENC_STYLE.get(cv["encoder"], dict(color="#444444", marker="o", ls="-"))
            ln, = ax.plot(cv["s"], cv["acc"], color=st["color"], marker=st["marker"], ls=st["ls"], ms=2.4, lw=0.9)
            hs.setdefault(cv["label"], ln)
        ax.set_xscale("function", functions=(np.log1p, np.expm1))
        ax.set_xlim(0, 256)
        ax.xaxis.set_major_locator(FixedLocator([0, 4, 16, 64, 256]))
        ax.xaxis.set_major_formatter(FuncFormatter(lambda v, p: f"{v:g}"))
        ax.xaxis.set_minor_locator(FixedLocator([]))
        ax.set_ylim(0, 1)
        ax.set_title(P["title"], fontsize=7, loc="right")
        panel_label(ax, f"({chr(97 + k)})")
    if not panels:
        axs[0, 0].set_axis_on()
        no_data(axs[0, 0])
    axs[1, 2].set_xlabel("blur $s$ (px$^2$, log1p axis)")
    fig.supylabel("probe accuracy on A2", fontsize=8)
    if hs:
        fig.legend(handles=list(hs.values()), labels=list(hs.keys()), loc="outside lower center", ncol=6, handlelength=2.0)
    return fig

# ---------------------------------------------------------------- Figure S10: invariance vs robustness
@figure("figS10_invariance_vs_robustness")
def figS10_invariance_vs_robustness(d):
    fig, ax = plt.subplots(figsize=d["figsize"])
    pts = [p for p in (d.get("points") or []) if np.isfinite(p["x"]) and np.isfinite(p["y"])]
    if not pts:
        no_data(ax)
        return fig
    for p in pts:
        st = ENC_STYLE.get(p["encoder"], dict(color="#444444", marker="o"))
        ax.errorbar([p["x"]], [p["y"]], xerr=err(p["x"], p["xlo"], p["xhi"]), yerr=err(p["y"], p["ylo"], p["yhi"]), fmt=st["marker"],
                    color=st["color"], ms=4, lw=0.7, capsize=1.2)
    xs = finite([p[k] for p in pts for k in ("xlo", "xhi", "x")])
    ys = finite([p[k] for p in pts for k in ("ylo", "yhi", "y")])
    ax.set_xlim(min(xs.min(), 0.0) - 0.08, max(xs.max(), 1.0) + 0.08)
    ax.set_ylim(min(ys.min(), 0.0) - 2.0, ys.max() + 0.12 * (ys.max() - min(ys.min(), 0.0)) + 3.0)
    ax.axvline(0.6, color="#777777", ls="--", lw=0.5, zorder=0)
    ax.axvline(0.8, color="#777777", ls="--", lw=0.5, zorder=0)
    ax.set_xlabel("feature knee $\\rho$ (mean of the two screen datasets)")
    ax.set_ylabel("accuracy drop $A(0)-A(64)$ (pp)")
    hs = [handle(ENC_STYLE.get(p["encoder"], {}).get("color", "#444444"), ENC_STYLE.get(p["encoder"], {}).get("marker", "o"), p["label"]) for p in pts]
    fig.legend(handles=hs, loc="outside lower center", ncol=3, handlelength=1.0, columnspacing=1.0)
    return fig

# ---------------------------------------------------------------- Figure S11: prediction scatter by regime
@figure("figS11_prediction_scatter")
def figS11_prediction_scatter(d):
    fig, axs = plt.subplots(1, 3, figsize=d["figsize"], sharex=True, sharey=True)
    hs = {}
    for k, (ax, P) in enumerate(zip(axs, d["panels"])):
        if P and len(P["truth"]):
            t = np.asarray(P["truth"], float)
            for s in P["series"]:
                scat(ax, t, np.asarray(s["pred"], float), s["color"], s["marker"], s=3.0, alpha=0.45, rasterized=True)
                hs.setdefault(s["legend"], handle(s["color"], s["marker"], s["legend"]))
            ax.plot([0, 1], [0, 1], color="black", lw=0.6, ls="--")
            ax.set_xlabel(P["xlabel"])
        else:
            no_data(ax)
        ax.set_xlim(0, 1)
        ax.set_ylim(0, 1)
        panel_label(ax, "(" + "abc"[k] + ")")
    axs[0].set_ylabel("predicted accuracy")
    if hs:
        fig.legend(handles=list(hs.values()), loc="outside lower center", ncol=min(5, len(hs)), handlelength=1.2)
    return fig

# ---------------------------------------------------------------- Figure S12: gallery
@figure("figS12_gallery")
def figS12_gallery(d):
    fig = plt.figure(figsize=d["figsize"])
    gs = fig.add_gridspec(1, 5, width_ratios=[1, 1, 1, 1, 0.55])
    axs = [fig.add_subplot(gs[0, i]) for i in range(5)]
    for ax in axs:
        ax.set_anchor("N")                                   # images hang from the top; labels stay inside the canvas
    L = d.get("ladder")
    for k in range(4):
        ax = axs[k]
        if L:
            ax.imshow(np.asarray(L["imgs"][k], np.uint8), interpolation="none")
            ax.set_xlabel(L["labels"][k])
        else:
            no_data(ax, d.get('missing_msg', 'no data in this run'))
        image_axes(ax)
        panel_label(ax, f"({chr(97 + k)})")
    O = d.get("obs")
    ax = axs[4]
    if O:
        hi, lo = np.asarray(O["high"], np.uint8), np.asarray(O["low"], np.uint8)
        gap = np.full((12, hi.shape[1], 3), 255, np.uint8)
        ax.imshow(np.concatenate([hi, gap, lo], 0), interpolation="none")
        box = dict(boxstyle="round,pad=0.15", fc="black", ec="none", alpha=0.55)
        ax.text(8, 10, O["high_label"], ha="left", va="top", fontsize=6.5, color="white", bbox=box)
        ax.text(8, hi.shape[0] + 12 + 10, O["low_label"], ha="left", va="top", fontsize=6.5, color="white", bbox=box)
        ax.set_xlabel("obs. extremes")
    else:
        no_data(ax, d.get('missing_msg', 'no data in this run'))
    image_axes(ax)
    panel_label(ax, "(e)")
    return fig

# ---------------------------------------------------------------- Figure 6: limits
@figure("fig6_limits")
def fig6_limits(d):
    fig, axs = plt.subplots(1, 3, figsize=d["figsize"])
    a, b, c = axs
    hs = []
    A = d.get("noisy")
    if A and A["series"]:
        allv = list(A["s0"])
        for s in A["series"]:
            x = np.asarray(A["s0"], float) * s.get("xshift", 1.0)
            med, q1, q3 = (np.asarray(s[k], float) for k in ("med", "q1", "q3"))
            ok = np.isfinite(med) & (med > 0)
            a.errorbar(x[ok], med[ok], yerr=err(med[ok], np.maximum(q1[ok], 1e-3), q3[ok]), fmt=s["marker"], ls=s["ls"], color=s["color"],
                       ms=3.2, lw=0.9, capsize=1.2, mfc=s["color"] if s.get("filled", True) else "white")
            hs.append(handle(s["color"], s["marker"], "(a) " + s["label"], filled=s.get("filled", True), ls=s["ls"]))
            allv += list(finite(q3[ok])) + list(finite(np.maximum(q1[ok], 1e-3)))
        allv = finite(allv)
        lo, hi = max(allv.min() / 1.5, 1e-2), allv.max() * 1.5
        a.plot([lo, hi], [lo, hi], color="black", ls="--", lw=0.6)
        a.set_xscale("log")
        a.set_yscale("log")
        a.set_xlim(lo, hi)
        a.set_ylim(lo, hi)
        log_ticks(a.xaxis, lo, hi)
        log_ticks(a.yaxis, lo, hi)
        a.set_xlabel("true $s_0$ (px$^2$), $\\sigma$ = 3 DN")
        a.set_ylabel("identified $s$ (px$^2$)")
    else:
        no_data(a)
    panel_label(a, "(a)")
    B = d.get("nb")
    if B and len(B["x"]):
        x, y = np.asarray(B["x"], float), np.asarray(B["y"], float)
        b.scatter(x, y, s=12, color="#0072B2", marker="o", linewidths=0)
        b.axhline(B["max_clean"], color="black", ls=":", lw=0.7)
        pad = max(0.02, 0.15 * (np.nanmax(x) - np.nanmin(x)))
        b.set_xlim(np.nanmin(x) - pad, np.nanmax(x) + 3 * pad)
        b.set_ylim(-0.05, max(0.3, np.nanmax(y) + 0.12))
        b.set_xlabel("narrowband index NB (median, clean B)")
        b.set_ylabel("clean false-flag rate")
    else:
        no_data(b)
    panel_label(b, "(b)")
    C = d.get("obs")
    if C and len(C["dec"]):
        x = np.asarray(C["dec"], float)
        med, q1, q3 = (np.asarray(C[k], float) for k in ("med", "q1", "q3"))
        c.fill_between(x, q1, q3, color="#0072B2", alpha=0.2, lw=0)
        c.plot(x, med, color="#0072B2", marker="o", ms=3)
        c.set_yscale("log")
        c.yaxis.set_minor_formatter(NullFormatter())
        c.set_xticks(x)
        c.set_xlabel(C["xlabel"])
        c.set_ylabel("identification error")
        fix_log(c)
    else:
        no_data(c)
    panel_label(c, "(c)")
    if hs:
        hs.append(Line2D([], [], color="black", ls="--", lw=0.6, label="(a) identity"))
        hs.append(Line2D([], [], color="black", ls=":", lw=0.7, label="(b) F5 bound 0.10"))
        fig.legend(handles=hs, loc="outside lower center", ncol=4, handlelength=1.8, columnspacing=1.2)
    if B and len(B["x"]):
        place_labels(b, np.asarray(B["x"], float), np.asarray(B["y"], float), B["labels"])
    return fig

# ---------------------------------------------------------------- Figure S5: estimator ablation
@figure("figS5_estimator_ablation")
def figS5_estimator_ablation(d):
    fig, axs = plt.subplots(1, 2, figsize=d["figsize"])
    for k, (ax, P) in enumerate(zip(axs, d["panels"])):
        if not P or not P["rows"]:
            no_data(ax)
            panel_label(ax, "(" + "ab"[k] + ")")
            continue
        rows = P["rows"]
        y = np.arange(len(rows))[::-1].astype(float)
        if P.get("oracle"):
            o = P["oracle"]
            ax.axvspan(o["lo"], o["hi"], color="#DDDDDD", lw=0, zorder=0)
            ax.axvline(o["x"], color="black", ls="--", lw=0.8, zorder=1)
        two = any(r.get("b") for r in rows)
        for yi, r in zip(y, rows):
            for key, dy, filled in (("a", 0.12 if two else 0.0, True), ("b", -0.12, False)):
                v = r.get(key)
                if not v or not np.isfinite(v[0]):
                    continue
                mk = ("o" if filled else "s") if two else (r["marker"] if r["marker"] not in UNFILLED else "o")
                ax.errorbar([v[0]], [yi + dy], xerr=err(v[0], v[1], v[2]), fmt=mk, color=r["color"], ms=3.8, lw=0.8, capsize=1.2,
                            mfc=(r["color"] if filled else "white"), mec="#333333" if filled else r["color"], mew=0.6)
        ax.set_yticks(y)
        ax.set_yticklabels([r["label"] for r in rows])
        ax.set_ylim(-0.6, len(rows) - 0.4)
        ax.set_xlabel(P["xlabel"])
        panel_label(ax, "(" + "ab"[k] + ")")
    hs = [Line2D([], [], color="black", ls="--", lw=0.8, label="oracle ATC (true $s_0,\\sigma_0$; not label-free)"),
          Patch(fc="#DDDDDD", ec="none", label="oracle 95% CI")]
    if any(P and P.get("legend_b") for P in d["panels"]):
        hs += [handle("#555555", "o", "(b) " + d["panels"][1]["legend_a"], True), handle("#555555", "s", "(b) " + d["panels"][1]["legend_b"], False)]
    fig.legend(handles=hs, loc="outside lower center", ncol=4, handlelength=1.6, columnspacing=1.0)
    return fig

# ---------------------------------------------------------------- Figure S6: identification sensitivity
@figure("figS6_identification_sensitivity")
def figS6_identification_sensitivity(d):
    fig, axs = plt.subplots(1, 4, figsize=d["figsize"])
    a, b, c, e = axs
    hs = []
    V = d.get("variants")
    if V and V["names"]:
        x = np.arange(len(V["names"]), dtype=float)
        for key, dx, filled, lab in (("clean", -0.12, True, "clean in-family"), ("ls", 0.12, False, "label shift")):
            med, q1, q3 = (np.asarray(V[key][k], float) for k in ("med", "q1", "q3"))
            a.errorbar(x + dx, med, yerr=err(med, q1, q3), fmt="o", color="#0072B2", mfc="#0072B2" if filled else "white", ms=3.4, lw=0.7,
                       capsize=1.2)
            hs.append(handle("#0072B2", "o", "(a) " + lab, filled=filled))
        a.axhline(V["f4"], color="black", ls=":", lw=0.7)
        hs.append(Line2D([], [], color="black", ls=":", lw=0.7, label="(a) F4 threshold 0.15"))
        a.set_xticks(x)
        a.set_xticklabels(V["names"])
        a.set_yscale("log")
        fix_log(a)
        a.set_ylabel("median rel. error")
        a.set_xlabel("identification variant")
    else:
        no_data(a)
    panel_label(a, "(a)")
    G = d.get("alpha")
    if G:
        al = list(G["alpha"])
        xa = np.arange(len(al), dtype=float)
        hs += b.plot(xa, G["clean"], color="#0072B2", marker="o", ms=3, label="(b) clean")
        hs += b.plot(xa, G["noisy"], color="#CC79A7", marker="^", ms=3, ls="--", label="(b) $\\sigma$ = 3 DN")
        if G["frozen"] in al:
            b.axvline(al.index(G["frozen"]), color="#777777", ls=":", lw=0.7)
        b.axhline(0.10, color="black", ls=":", lw=0.5)
        b.axhline(0.90, color="black", ls=":", lw=0.5)
        b.set_xticks(xa)
        b.set_xticklabels([f"{v:g}" for v in al])
        b.set_xlim(-0.4, len(al) - 0.6)
        b.set_ylim(-0.03, 1.03)
        b.set_xlabel("GOF $\\alpha$")
        b.set_ylabel("flag rate")
    else:
        no_data(b)
    panel_label(b, "(b)")
    K = d.get("K")
    if K:
        kk = np.asarray(K["K"], float)
        med, q1, q3 = (np.asarray(K[k], float) for k in ("med", "q1", "q3"))
        c.errorbar(kk, med, yerr=err(med, q1, q3), fmt="o-", color="#0072B2", ms=3.2, lw=0.9, capsize=1.2)
        c.set_xticks(kk)
        c.set_xticklabels([f"{int(v)}" for v in kk])
        c.set_yscale("log")
        fix_log(c)
        c.set_xlabel("number of $\\eta$ levels $K$")
        c.set_ylabel("median rel. error")
    else:
        no_data(c)
    panel_label(c, "(c)")
    Q = d.get("nq")
    if Q and len(Q["n"]):
        n = np.asarray(Q["n"], float)
        med, q1, q3 = (np.asarray(Q[k], float) for k in ("med", "q1", "q3"))
        e.fill_between(n, np.maximum(q1, 1e-4), q3, color="#0072B2", alpha=0.2, lw=0)
        hs += e.plot(n, med, color="#0072B2", marker="o", ms=3, label="(d) " + Q["label"])
        if len(Q.get("all_n", [])):
            e.scatter(Q["all_n"], np.maximum(np.asarray(Q["all_err"], float), 1e-4), s=6, facecolors="none", edgecolors="#0072B2", linewidths=0.5)
            hs.append(handle("#0072B2", "o", "(d) $n_Q$ = all", filled=False, ms=3))
        e.set_xscale("log")
        e.set_yscale("log")
        log_ticks(e.xaxis, n.min(), max(n.max(), max(Q.get("all_n", [n.max()]))), fmt=lambda v, p: f"{v:g}")
        fix_log(e)
        e.set_xlabel("target size $n_Q$")
        e.set_ylabel("rel. error")
    else:
        no_data(e)
    panel_label(e, "(d)")
    if hs:
        fig.legend(handles=hs, loc="outside lower center", ncol=4, handlelength=1.6, columnspacing=1.0)
    return fig

# ---------------------------------------------------------------- Figure S7: efficiency
@figure("figS7_efficiency")
def figS7_efficiency(d):
    fig, ax = plt.subplots(figsize=d["figsize"])
    pts = [p for p in (d.get("points") or []) if np.isfinite(p["mae"])]
    if not pts:
        no_data(ax)
        return fig
    floor = d["floor"]
    xs = np.array([max(p["cost"], floor) for p in pts])
    ys = np.array([p["mae"] for p in pts])
    for p, x, y in zip(pts, xs, ys):
        mk = p["marker"]
        ax.scatter([x], [y], s=26 if p["key"] == "ATC_s" else 16, marker=mk, color=p["color"], linewidths=(0.8 if mk in UNFILLED else 0),
                   zorder=3)
    order = np.argsort(xs, kind="stable")
    fx, fy, best = [], [], np.inf
    for i in order:
        if ys[i] < best:
            best = ys[i]
            fx.append(xs[i])
            fy.append(ys[i])
    ax.step(fx, fy, where="post", color="#555555", lw=0.8, ls="--", zorder=1)
    ax.set_xscale("log")
    hi = xs.max() * 3
    ax.set_xlim(floor / 2, hi)
    ticks = [floor] + [10.0 ** k for k in range(int(np.ceil(np.log10(floor * 3))), int(np.floor(np.log10(hi))) + 1)]
    ax.xaxis.set_major_locator(FixedLocator(ticks))
    ax.xaxis.set_minor_formatter(NullFormatter())
    ax.xaxis.set_major_formatter(FuncFormatter(lambda v, p: "0" if abs(v - floor) < 1e-9 * floor else f"{v:g}"))
    ax.set_xlabel("extra GPU-seconds per (dataset, encoder)")
    ax.set_ylabel("unflagged MAE (pp)")
    hs = [handle(p["color"], p["marker"], p["label"]) for p in pts] + [Line2D([], [], color="#555555", ls="--", lw=0.8, label="Pareto frontier")]
    fig.legend(handles=hs, loc="outside lower center", ncol=4, handlelength=1.0, columnspacing=0.6, handletextpad=0.3)
    return fig

# ---------------------------------------------------------------- Figure S9: real shifts
@figure("figS9_real_shifts")
def figS9_real_shifts(d):
    fig, axs = plt.subplots(1, 3, figsize=d["figsize"], sharey=True)
    methods = d.get("methods") or []
    n = len(methods)
    y = np.arange(n)[::-1].astype(float)
    xmax = 0.0
    for k, (ax, P) in enumerate(zip(axs, d["panels"])):
        if P is None or not P["rows"]:
            no_data(ax, "pair missing")
        else:
            for yi, r in zip(y, P["rows"]):
                e_, fl, jit = (np.asarray(r[k_], float) for k_ in ("err", "flagged", "jitter"))
                for filled in (True, False):
                    m = (fl < 0.5) if filled else (fl >= 0.5)
                    if m.any():
                        scat(ax, e_[m], yi + jit[m], r["color"], r["marker"], s=7, alpha=0.75, filled=filled)
                ax.plot([r["mean"]], [yi], marker="|", color="black", ms=7, mew=1.2)
                xmax = max(xmax, float(np.nanmax(e_)) if len(e_) else 0.0)
            ax.set_title(P["title"], fontsize=7)
        ax.set_xlabel("absolute error (pp)")
        panel_label(ax, "(" + "abc"[k] + ")")
    for ax in axs:
        ax.set_xlim(0, xmax * 1.08 + 0.5)
    axs[0].set_yticks(y)
    axs[0].set_yticklabels([plain_label(m) for m in methods], fontsize=6.5)
    axs[0].set_ylim(-0.6, n - 0.4)
    for ax in axs[1:]:
        ax.tick_params(labelleft=False)
    hs = [handle("#555555", "o", "unflagged condition", True), handle("#555555", "o", "flagged condition", False),
          Line2D([], [], color="black", marker="|", ls="none", ms=7, mew=1.2, label="mean over cells")]
    fig.legend(handles=hs, loc="outside lower center", ncol=3)
    return fig

# ---------------------------------------------------------------- Figure S13: stress tests
@figure("figS13_stress_tests")
def figS13_stress_tests(d):
    fig, axs = plt.subplots(1, 3, figsize=d["figsize"])
    a, b, c = axs
    hs = []
    N = d.get("noise")
    if N and N["series"]:
        allv = []
        for s in N["series"]:
            x, yv = np.asarray(s["s0"], float), np.asarray(s["med"], float)
            ok = np.isfinite(yv) & (yv > 0)
            a.plot(x[ok], yv[ok], color=s["color"], marker=s["marker"], ls=s["ls"], ms=2.8, lw=0.9, mfc=s["color"] if s["ls"] == "-" else "white")
            allv += list(x) + list(yv[ok])
        allv = finite(allv)
        lo, hi = max(allv.min() / 1.5, 1e-2), allv.max() * 1.5
        a.plot([lo, hi], [lo, hi], color="black", ls=":", lw=0.6)
        a.set_xscale("log")
        a.set_yscale("log")
        a.set_xlim(lo, hi)
        a.set_ylim(lo, hi)
        log_ticks(a.xaxis, lo, hi)
        log_ticks(a.yaxis, lo, hi)
        hs += [handle(s["color"], s["marker"], "(a) " + s["legend"], ls="-") for s in N["series"] if s["ls"] == "-"]
        hs += [Line2D([], [], color="#555555", ls="-", lw=0.9, label="(a) v1.0 joint fit"),
               Line2D([], [], color="#555555", ls="--", lw=0.9, label="(a) v1.1 tail fit")]
        a.set_xlabel("true $s_0$ (px$^2$)")
        a.set_ylabel("identified $s$ (px$^2$)")
    else:
        no_data(a)
    panel_label(a, "(a)")
    P = d.get("psf")
    if P and P["groups"]:
        allv = []
        for g in P["groups"]:
            x, yv = np.asarray(g["truth"], float), np.asarray(g["med"], float)
            q1, q3 = np.asarray(g["q1"], float), np.asarray(g["q3"], float)
            b.errorbar(x, yv, yerr=err(yv, q1, q3), fmt=g["marker"], color=g["color"], ms=3.4, lw=0.7, capsize=1.2)
            hs.append(handle(g["color"], g["marker"], "(b) " + g["label"]))
            allv += list(finite(x)) + list(finite(q1)) + list(finite(q3))
        allv = finite(allv)
        allv = allv[allv > 0]
        lo, hi = allv.min() / 1.5, allv.max() * 1.5
        b.plot([lo, hi], [lo, hi], color="black", ls="--", lw=0.6)
        b.set_xscale("log")
        b.set_yscale("log")
        b.set_xlim(lo, hi)
        b.set_ylim(lo, hi)
        log_ticks(b.xaxis, lo, hi)
        log_ticks(b.yaxis, lo, hi)
        b.set_xlabel("Gaussian-equivalent variance (px$^2$)")
        b.set_ylabel("identified $\\hat{s}$ (px$^2$)")
    else:
        no_data(b)
    panel_label(b, "(b)")
    J = d.get("jpeg")
    if J and len(J["q"]):
        q = np.asarray(J["q"], float)
        for xs_, ys_ in zip(J["per_ds_q"], J["per_ds_rate"]):
            c.plot(xs_, ys_, color="#BBBBBB", lw=0.6, zorder=1)
        hs += c.plot(q, J["mean"], color="#0072B2", marker="o", ms=3.2, lw=1.2, zorder=2, label="(c) mean over datasets")
        hs.append(Line2D([], [], color="#BBBBBB", lw=0.6, label="(c) per dataset"))
        c.set_ylim(-0.03, 1.03)
        c.set_xticks(q)
        c.set_xlabel("JPEG quality")
        c.set_ylabel("GOF flag rate")
    else:
        no_data(c)
    panel_label(c, "(c)")
    if hs:
        fig.legend(handles=hs, loc="outside lower center", ncol=4, handlelength=1.6, columnspacing=1.0, fontsize=6.5)
    return fig


# ---------------------------------------------------------------- standalone regeneration
def _load_figure_data(logs_dir, stem):
    with open(os.path.join(logs_dir, f"{stem}_data.json"), encoding="utf-8") as f:
        d = json.load(f)
    npz = d.pop("__npz_file__", None)
    if npz:
        arrs = np.load(os.path.join(logs_dir, npz))
        def _fill(o):
            if isinstance(o, dict):
                if set(o) == {"__npz__"}:
                    return arrs[o["__npz__"]]
                return {k: _fill(v) for k, v in o.items()}
            if isinstance(o, list):
                return [_fill(v) for v in o]
            return o
        d = _fill(d)
    return d

def main(logs_dir="logs", out_dir="figures_regenerated"):
    """Regenerate every figure from logs/<stem>_data.json (+ .npz) with numpy and matplotlib only."""
    os.makedirs(out_dir, exist_ok=True)
    for stem, fn in FIGS.items():
        if not os.path.exists(os.path.join(logs_dir, f"{stem}_data.json")):
            print("no data for", stem)
            continue
        fig = fn(_load_figure_data(logs_dir, stem))
        fig.savefig(os.path.join(out_dir, stem + ".pdf"))
        fig.savefig(os.path.join(out_dir, stem + ".png"), dpi=600)
        plt.close(fig)
        print("regenerated", stem)

if __name__ == "__main__":
    import sys
    main(*sys.argv[1:])
